# Product plan

## Goal
Multi-sport analytics and decision support.

## Scope
NFL, NBA, WNBA, MLB, and NHL views; data provenance, projections, uncertainty, and an aggression lab for comparing higher-risk assumptions.

## First milestone
- Choose a technology stack and document tradeoffs.
- Identify data sources, access limits, and privacy considerations.
- Build one working flow with clear tests.
- Write setup and deployment instructions.

## Not yet implemented
The current repository is a scaffold only.
